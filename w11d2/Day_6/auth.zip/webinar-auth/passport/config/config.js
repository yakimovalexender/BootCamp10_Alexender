module.exports = {
  github: {
    clientID: '4cbf11707d238ed79f0e',
    clientSecret: '619e65e95fd1544a075b1b32cca22fe9f5fc8859',
    callbackURL: 'http://localhost:3000/auth/github/callback',
  },
};
